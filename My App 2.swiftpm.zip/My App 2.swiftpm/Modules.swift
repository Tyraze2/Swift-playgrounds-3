import SwiftUI

class Animal {
    var name: String
    init(name: String) {
        self.name = name
        func sound() {
            print("grrrr...")
        }
    }
}


class dog: Animal {
    override func sound() {
        print("woof")
    }
}

class cat: Animal {
    override func sound() {
        print("meow")
    }
}
